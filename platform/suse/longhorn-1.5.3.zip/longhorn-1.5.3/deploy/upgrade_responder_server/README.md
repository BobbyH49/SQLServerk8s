This directory contains the helm values for the Longhorn upgrade responder server. 
The values are in the file `./chart-values.yaml`.
When you update the content of `./chart-values.yaml`, automation pipeline will update the Longhorn upgrade responder.

The chart source chart is in `chart.yaml`