// SPDX-License-Identifier:Apache-2.0

// Placeholder file to make Go vendor this directory properly.
package template
