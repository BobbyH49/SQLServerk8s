// SPDX-License-Identifier:Apache-2.0

// +groupName=metallb.io
package v1beta2
