// SPDX-License-Identifier:Apache-2.0

package v1beta1

// Hub marks this type as a conversion hub.
func (*AddressPool) Hub() {}
